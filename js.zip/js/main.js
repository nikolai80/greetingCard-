(function () {
    greeting.greetings.init();
    greeting.news.init();
    greeting.history.init();
    greeting.photos.init();
})();